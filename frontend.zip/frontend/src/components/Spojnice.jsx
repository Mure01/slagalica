import React from 'react'

const Spojnice = () => {
  return (
    <div>Spojnice</div>
  )
}

export default Spojnice