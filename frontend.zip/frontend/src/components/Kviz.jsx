import React from 'react'

const Kviz = () => {
  return (
    <div>Kviz</div>
  )
}

export default Kviz